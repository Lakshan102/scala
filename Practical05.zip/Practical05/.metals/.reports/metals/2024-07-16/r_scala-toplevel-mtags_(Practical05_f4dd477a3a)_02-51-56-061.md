error id: file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala:[6..6) in Input.VirtualFile("file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala", "object")
file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala
file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala:1: error: expected identifier; obtained eof
object
      ^
#### Short summary: 

expected identifier; obtained eof