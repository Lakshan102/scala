error id: file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala:[27..28) in Input.VirtualFile("file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala", "object Fibonacci{
    def 
}")
file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala
file://<HOME>/Documents/UCSC%202024/scala/Practical05/P05_Q)3.scala:3: error: expected identifier; obtained rbrace
}
^
#### Short summary: 

expected identifier; obtained rbrace